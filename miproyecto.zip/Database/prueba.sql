INSERT INTO notitia.usuario (nombre_usuario,contraseña, correo, es_informador)
VALUES ('Yo','password','asdfas',false);

INSERT INTO notitia.temas (nombre, descripcion)
VALUES ('rigoberto','magic');
INSERT INTO notitia.temas (nombre, descripcion)
VALUES ('alberto','magic');
INSERT INTO notitia.temas (nombre, descripcion)
VALUES ('roberto','magic');
INSERT INTO notitia.temas (nombre, descripcion)
VALUES ('canto','mahou');
